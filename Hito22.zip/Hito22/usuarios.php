<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<table class="table table-bordered">
    <thead>
    <tr>
        <th scope="col">id</th>
        <th scope="col">Nombre</th>
        <th scope="col">Contraseña</th>
        <th scope="col">Repetir Contraseña</th>
        <th scope="col">email</th>
        <th scope="col">rol</th>
    </tr>
    </thead>
    <tbody>
<?php
require_once ("hito.php");

$conexion=new conexion();

session_start();
if ($_SESSION['usuario']=="mario") {
    $datos1 = $conexion->conectar()->query("SELECT * FROM USUARIOS");
    while ($fila = mysqli_fetch_array($datos1)) {
        echo "
        <tr>
        <th class='table-secondary' scope='row'>" . $fila[0] . "</th>
        <td class='table-info'>" . $fila[1] . "</td>
        <td class='table-secondary'>" . $fila[2] . "</td>
        <td class='table-info'>" . $fila[3] . "</td>
        <td class='table-secondary'>" . $fila[4] . "</td>
        <td class='table-secondary'>" . $fila[5] . "</td>
        </tr>
        ";
    }
}else{

    $usuario=$_SESSION['usuario'];
    $datos2 = $conexion->conectar()->query("SELECT * FROM USUARIOS WHERE nombre='$usuario'");
    while ($fila = mysqli_fetch_array($datos2)) {
        echo "
        <tr>
        <th class='table-secondary' scope='row'>" . $fila[0] . "</th>
        <td class='table-info'>" . $fila[1] . "</td>
        <td class='table-secondary'>" . $fila[2] . "</td>
        <td class='table-info'>" . $fila[3] . "</td>
        <td class='table-secondary'>" . $fila[4] . "</td>
        <td class='table-secondary'>" . $fila[5] . "</td>
        </tr>
        ";
    }

}
?>
    </tbody>
</table>
</body>
</html>




