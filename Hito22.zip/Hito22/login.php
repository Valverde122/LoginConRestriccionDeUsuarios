<?php
require_once ('hito.php');

$nombre=$_POST['Usuario'];
$pass=$_POST['Contraseña'];

session_start();
$_SESSION['usuario']=$nombre;
header("location: ./index.html");





