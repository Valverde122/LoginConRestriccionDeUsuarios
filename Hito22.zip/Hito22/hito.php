<?php
class conexion{
    public function conectar(): mysqli
    {
        return new mysqli("localhost","root","","hito");
    }
}