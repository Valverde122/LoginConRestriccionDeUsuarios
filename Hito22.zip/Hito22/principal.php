<?php
if (isset($_POST['cerrarSesion'])) {
    session_destroy();
    header('Location: ./index.html');
}