<?php
require_once('hito.php');
$conexion= new conexion();


$email=$_POST['email'];
$contraseña=$_POST['contraseña'];
$repetir_contraseña=$_POST['repetir_contraseña'];
$nombre=$_POST['nombre'];

$conexion->conectar()->query("INSERT INTO hito.usuarios VALUES(null,'$nombre','$contraseña','$repetir_contraseña','$email','normal')");

echo "usuario registrado";
echo "<a class='btn btn-primary' href='index.html'>Ir a inicio</a>";